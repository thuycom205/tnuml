# -*- coding: utf-8 -*-

from odoo import models, fields, api


class aws_exam(models.Model):
    _name = 'aws_question.aws_exam'
    _description = 'exam'

    name = fields.Char()

    is_topic = fields.Boolean(
        string='Topic',
        default=True)

    description = fields.Text()
    question_ids = fields.One2many('aws_question.aws_question' , 'exam_id', string='Question')


class aws_question(models.Model):
    _name = 'aws_question.aws_question'
    _description = 'question'

    name = fields.Char(default='question')
    question = fields.Text(string="Question")
    answer = fields.Text(string="Answer")
    note = fields.Html(string = "Note")
    incorrect_count = fields.Integer(string="InCorrect count")
    description = fields.Text()

    exam_id = fields.Many2one('aws_question.aws_exam', string='Exam')
    priority_id = fields.Many2one('aws_question.aws_priority', string='Priority')
    tags_ids = fields.Many2many(string="Tags", comodel_name='aws_question.aws_tag',)




class aws_tag(models.Model):
    _name = 'aws_question.aws_tag'
    _description = 'aws_question.tag'

    name = fields.Char()
    question_ids = fields.Many2many(string="Question", comodel_name='aws_question.aws_question')

    description = fields.Text()

class aws_priority(models.Model):
    _name = 'aws_question.aws_priority'
    _description = 'aws_question.aws_priority'

    priority = fields.Integer(string="Priority")
    question_ids = fields.One2many('aws_question.aws_question' , 'priority_id', string='Question')

    def name_get(self):
        return [(seniority.id, str(seniority.priority)) for seniority in self]




